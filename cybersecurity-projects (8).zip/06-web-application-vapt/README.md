# Web Application VAPT

Twelve findings against the intentionally vulnerable testfire.net / Altoro Mutual demo site.

- `Web_Application_VAPT_Report.pdf` – final report
- `Web_Application_VAPT_Report.docx` – editable source

> For educational use in authorised lab environments only.
