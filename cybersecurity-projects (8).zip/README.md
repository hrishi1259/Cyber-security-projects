# Cybersecurity Projects

| Project | Summary |
|---|---|
| [Network Vulnerability Assessment (VAPT)](./01-network-vulnerability-assessment) | Nmap, Nessus and Metasploit assessment of host 192.168.1.109: UnrealIRCd backdoor (Critical), rlogin cleartext service (High), Samba Badlock (Medium). |
| [EternalBlue (MS17-010) Exploitation and Analysis](./02-eternalblue-ms17-010) | Controlled lab exploitation of MS17-010 on Windows 7 SP1 from Kali Linux using Metasploit, with mitigations. |
| [SafeLine Web Application Firewall (WAF)](./03-safeline-waf) | DVWA on Docker, SQL injection test, SafeLine WAF protection and rate limiting. |
| [Malware Analysis Report](./04-malware-analysis) | Template-style analysis of a suspicious .exe using VirusTotal and Hybrid Analysis. |
| [AI-Powered SOC Analyst Agent](./05-ai-soc-analyst-agent) | Python agent that sends SSH auth-log entries to an AI model and applies SOC playbook rules. |
| [Web Application VAPT](./06-web-application-vapt) | Twelve findings against the intentionally vulnerable testfire.net / Altoro Mutual demo site. |

All work was performed in isolated lab environments or against intentionally vulnerable targets.
