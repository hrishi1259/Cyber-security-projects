# AI-Powered SOC Analyst Agent

Python agent that sends SSH auth-log entries to an AI model and applies SOC playbook rules.

- `AI_SOC_Analyst_Agent.pdf` – final report
- `AI_SOC_Analyst_Agent.docx` – editable source

> For educational use in authorised lab environments only.
