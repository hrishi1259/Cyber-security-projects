# EternalBlue (MS17-010) Exploitation and Analysis

Controlled lab exploitation of MS17-010 on Windows 7 SP1 from Kali Linux using Metasploit, with mitigations.

- `EternalBlue_MS17-010_Exploitation_Report.pdf` – final report
- `EternalBlue_MS17-010_Exploitation_Report.docx` – editable source

> For educational use in authorised lab environments only.
