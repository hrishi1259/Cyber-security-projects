# SafeLine Web Application Firewall (WAF)

DVWA on Docker, SQL injection test, SafeLine WAF protection and rate limiting.

- `SafeLine_WAF_Project.pdf` – final report
- `SafeLine_WAF_Project.docx` – editable source

> For educational use in authorised lab environments only.
